package data;

import java.util.concurrent.CopyOnWriteArrayList;

public class ParalizedTower extends Tower {
    public ParalizedTower(TowerType type, Tile towerTile, CopyOnWriteArrayList<Enemy> enemies) {
        super(type, towerTile, enemies);
    }

    @Override
    public void shoot(Enemy target) {
        super.projectiles.add(new ZapBullet(super.type.bulletType, super.target, super.getX(), super.getY(), 32, 32));
        super.target.reduceCheck(super.type.bulletType.damage);
    }
}
