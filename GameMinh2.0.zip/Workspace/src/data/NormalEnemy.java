package data;

public class NormalEnemy extends Enemy{
    public NormalEnemy(int x, int y, TileGrid grid) {
        super(x, y, grid);
    }
}
