package data;

import Audio.AudioPlayer;
import helpers.Clock;
import org.lwjgl.opengl.Display;

import static helpers.Artist.*;

public class Main {
    private AudioPlayer music;
    public Main() {
        beginSession();
        music = new AudioPlayer("/res/Music/backgound.mp3");
        music.play();

        while (!Display.isCloseRequested()){
            Clock.update();
            ManageTheMenu.update();
            Display.update();
            Display.sync(60);
        }
        Display.destroy();
    }

    public static void main(String[] args) {
        new Main();
    }
}
