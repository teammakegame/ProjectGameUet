package data;

//enum là kiểu liệt kê
public enum TileType {

    Grass("grass2", true), Dirt("road3", false), Water("water3", false), NULL("water", false);

    String  textureName;
    boolean buildable;

    //khai báo texture
    TileType (String textureName, boolean buidable){
        this.textureName = textureName;
        this.buildable = buildable;
    }
}
