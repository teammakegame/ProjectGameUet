package Game.Entity.Enemy;
import Game.Entity.GameTiles.Tile.TileGrid;

public class NormalEnemy extends Enemy{
    public NormalEnemy(int x, int y, TileGrid grid) {
        super(x, y, grid);
    }
}
