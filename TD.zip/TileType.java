package data;

public enum TileType {

    Grass("grass2", true), Dirt("road3", false), Water("water3", false), NULL("water", false);

    String textureName;
    boolean buildable;

    TileType (String textureName, boolean buidable){
        this.textureName = textureName;
        this.buildable = buildable;
    }
}
