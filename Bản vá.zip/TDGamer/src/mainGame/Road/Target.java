package mainGame.Road;

import mainGame.Enemy.Enemy;
import mainGame.GameStateManager.GameStage;
import mainGame.GameTile.TileGrid;

import static mainGame.GameStateManager.GameStage.GameState;

public class Target {
    private float timeSinceLastWave, timeBetweenEnemies; //thời gian từ lần spawn trước và thời gian giữa các enemy
    private int enemiesPerWave; //số lượng enemy một wave
    private Enemy[] enemyType; //kiểu enemy
    private Spawner currentWave; //wave hiện tại
    private TileGrid grid; //bản đồ
    public static int waveNumber; //số lượng wave

    public Target(Enemy[] enemyType, float timeBetweenEnemies, int enemiesPerWave, TileGrid grid) {
        this.enemyType =          enemyType;
        this.timeBetweenEnemies = timeBetweenEnemies;
        this.enemiesPerWave =     enemiesPerWave;
        this.timeSinceLastWave =  0;
        this.waveNumber =         0;
        this.currentWave =        null;
        this.grid = grid;
        newWave(); //wave đầu
    }

    public void update() {
        //vẽ wave chừng nào vẫn còn enemy
        if (!currentWave.isWaveCompleted()) {
            currentWave.update();
        }
        //nếu không thì tạo wave mới, bắt đầu wave tiếp theo
        else newWave();
    }

    public void newWave() {
        currentWave = new Spawner(enemyType, timeBetweenEnemies, enemiesPerWave); //tạo một wave
        waveNumber++; //số lượng wave tăng lên 1, nễu bằng 21 thì thoát game, người chơi thắng
        if (waveNumber == 21) {
            GameStage.setGameCondition(GameState.GAMEWIN);
        }
        enemiesPerWave += 3; //mỗi lượt thêm 3 enemy
    }

    public Spawner getCurrentWave() {return currentWave;}

    public int getWaveNumber() { return waveNumber; }
}
