package data;

import helpers.Clock;
import org.lwjgl.opengl.Display;
import Audio.AudioPlayer;

import static helpers.Artist.*;

public class Boot {
    private AudioPlayer music;

    public Boot() {
        beginSession();
        music = new AudioPlayer("/res/Music/backgound.mp3");
        music.play();

        //TileGrid grid = new TileGrid(map);
        //Wave wave = new Wave(20, e);
        //Player player = new Player(grid);
        //BasicTower tower = new BasicTower(quickLoad("cannon5"), grid.getTile(4, 1), 10);

        //Game game = new Game(map);
        while (!Display.isCloseRequested()){
            Clock.update();
            //grid.draw();
            //wave.Update();
            //player.update();
            //tower.update();
            //game.update();
            ManageTheMenu.update();
            Display.update();
            Display.sync(60);
        }
        Display.destroy();
    }

    public static void main(String[] args) {
        new Boot();
    }
}
