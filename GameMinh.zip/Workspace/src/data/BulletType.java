package data;

import org.newdawn.slick.opengl.Texture;

import static helpers.Artist.*;

public enum BulletType {

    NormalBullet(quickLoad("bullet"), 20, 500),
    ParalizedBullet(quickLoad("towerzapbullet"), 0, 450);

    Texture texture;
    int damage;
    float speed;

    BulletType(Texture texture, int damage, float speed) {
        this.texture = texture;
        this.damage = damage;
        this.speed = speed;
    }
}
