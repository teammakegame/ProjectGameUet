package mainGame.Enemy;

import mainGame.GameTile.TileGrid;

public class NormalEnemy extends Enemy {
    public NormalEnemy(int x, int y, TileGrid grid) {
        super(x, y, grid);
    }
}
